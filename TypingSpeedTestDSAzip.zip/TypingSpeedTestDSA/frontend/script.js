const paragraph = document.getElementById('paragraph').innerText.trim();
const inputBox = document.getElementById('inputBox');
const startBtn = document.getElementById('startBtn');
const submitBtn = document.getElementById('submitBtn');
const resetBtn = document.getElementById('resetBtn');
const liveFeedback = document.getElementById('liveFeedback');
const results = document.getElementById('results');

let startTime = null;

startBtn.addEventListener('click', () => {
  inputBox.value = '';
  inputBox.focus();
  startTime = Date.now();
  submitBtn.disabled = false;
  results.innerHTML = '';
  liveFeedback.innerHTML = '';
});

inputBox.addEventListener('input', () => {
  const typed = inputBox.value;
  // live character-level highlight (simple)
  let highlighted = '';
  for (let i = 0; i < paragraph.length; i++) {
    const pch = paragraph[i];
    const tch = typed[i];
    if (tch == null) {
      highlighted += pch;
    } else if (tch === pch) {
      highlighted += `<span class="correct">${pch}</span>`;
    } else {
      highlighted += `<span class="wrong">${pch}</span>`;
    }
  }
  liveFeedback.innerHTML = highlighted;
});

submitBtn.addEventListener('click', () => {
  const endTime = Date.now();
  const typed = inputBox.value;
  const timeTaken = Math.max((endTime - startTime) / 60000.0, 1/60000.0); // minutes
  // compute errors
  let errors = 0;
  const minLen = Math.min(typed.length, paragraph.length);
  for (let i = 0; i < minLen; i++) {
    if (typed[i] !== paragraph[i]) errors++;
  }
  errors += Math.abs(typed.length - paragraph.length);
  const correctChars = Math.max(0, typed.length - errors);
  const wpm = (typed.length / 5.0) / timeTaken;
  const accuracy = (correctChars * 100.0) / paragraph.length;

  results.innerHTML = `
    <div><strong>WPM:</strong> ${wpm.toFixed(2)}</div>
    <div><strong>Errors:</strong> ${errors}</div>
    <div><strong>Accuracy:</strong> ${accuracy.toFixed(2)}%</div>
    <div style="margin-top:8px; font-size:13px; color:#9aa4b2">Note: This frontend computes results locally.
    To use the Java backend for evaluation, run the Java program and pass start/end/typed as arguments (see README).</div>
  `;
});

resetBtn.addEventListener('click', () => {
  inputBox.value = '';
  results.innerHTML = '';
  liveFeedback.innerHTML = '';
  submitBtn.disabled = true;
  startTime = null;
});
