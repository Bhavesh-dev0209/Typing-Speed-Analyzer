import java.io.BufferedReader;
import java.io.InputStreamReader;

// Main simulates backend evaluation. It accepts three command-line arguments OR
// will run a built-in demo if none provided.
public class Main {
    public static void main(String[] args) throws Exception {
        String paragraph = "Data Structures and Algorithms are powerful.";
        String typed;
        long start;
        long end;

        if (args.length >= 3) {
            // args: startMillis endMillis typedString
            start = Long.parseLong(args[0]);
            end = Long.parseLong(args[1]);
            StringBuilder sb = new StringBuilder();
            for (int i = 2; i < args.length; i++) {
                if (i > 2) sb.append(" ");
                sb.append(args[i]);
            }
            typed = sb.toString();
        } else {
            // Demo mode: read typed line from stdin and measure time while user types.
            System.out.println("Paragraph to type:\n" + paragraph + "\n");
            System.out.println("When you are ready, press Enter to start. Then type the paragraph and press Enter to submit.");
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            br.readLine(); // wait for Enter to start
            System.out.println("Start typing now:");
            start = System.currentTimeMillis();
            typed = br.readLine();
            end = System.currentTimeMillis();
        }

        TypingTest test = new TypingTest(paragraph);
        test.startTest(typed, start, end);
        TestResult res = test.evaluate();
        System.out.println(res.toString());
    }
}
