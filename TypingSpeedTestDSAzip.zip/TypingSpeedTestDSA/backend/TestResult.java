public class TestResult {
    public double wpm;
    public int errors;
    public double accuracy;

    public TestResult(double wpm, int errors, double accuracy) {
        this.wpm = wpm;
        this.errors = errors;
        this.accuracy = accuracy;
    }

    @Override
    public String toString() {
        return String.format("WPM: %.2f\nErrors: %d\nAccuracy: %.2f%%", wpm, errors, accuracy);
    }
}
