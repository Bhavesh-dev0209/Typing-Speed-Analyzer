// Core typing test logic (no GUI, pure algorithmic logic).
public class TypingTest {
    private String paragraph;
    private String userInput;
    private long startTime, endTime;

    public TypingTest(String para) {
        this.paragraph = para;
    }

    // Populate input and timestamps (timestamps in ms)
    public void startTest(String input, long start, long end) {
        this.userInput = input == null ? "" : input;
        this.startTime = start;
        this.endTime = end;
    }

    public TestResult evaluate() {
        int minLen = Math.min(userInput.length(), paragraph.length());
        int errors = 0;
        for (int i = 0; i < minLen; i++) {
            if (userInput.charAt(i) != paragraph.charAt(i)) errors++;
        }
        // Count remaining chars as errors if lengths differ
        errors += Math.abs(userInput.length() - paragraph.length());

        int correctChars = Math.max(0, userInput.length() - errors);

        double timeTakenMinutes = Math.max( (endTime - startTime) / 60000.0, 1.0/60000.0 ); // avoid div by zero
        double wpm = (userInput.length() / 5.0) / timeTakenMinutes;
        double accuracy = (paragraph.length() == 0) ? 0.0 : (correctChars * 100.0) / paragraph.length();

        return new TestResult(wpm, errors, accuracy);
    }
}
