// Core string matching helpers — KMP-based utilities could be extended.
public class StringMatcher {

    // Returns the index of first mismatch between original and typed.
    // If typed has extra chars at the end, returns minLength (index after last compared).
    // Returns -1 if exact match.
    public static int firstMismatch(String original, String typed) {
        int n = Math.min(original.length(), typed.length());
        for (int i = 0; i < n; i++) {
            if (original.charAt(i) != typed.charAt(i)) {
                return i; // first mismatch index
            }
        }
        if (typed.length() != original.length()) {
            return n; // mismatch due to different length
        }
        return -1; // No mismatch
    }
}
