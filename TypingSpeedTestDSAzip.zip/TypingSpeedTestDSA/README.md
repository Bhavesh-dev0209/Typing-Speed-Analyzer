# TypingSpeedTestDSA

This project includes:
- `backend/` — pure Java files containing the algorithmic logic (WPM, accuracy, mismatch detection).
- `frontend/` — a reactive website (HTML/CSS/JS) that provides live feedback and computes results locally.
- The frontend is intentionally kept simple and *does local evaluation* so you can open `frontend/index.html` directly.

## How to run (Frontend)
1. Open `frontend/index.html` in your browser (double-click or use Live Server extension).
2. Click **Start Test**, type the paragraph, then **Submit** to see WPM, errors, and accuracy.

## How to run (Backend demo)
You can run the Java backend to test the pure algorithmic logic.

Requirements: Java 11+ and `javac`/`java` on PATH.

1. Compile:
   ```bash
   cd backend
   javac *.java
   ```
2. Run demo (interactive): 
   ```bash
   java Main
   ```
   - The program will prompt you. Press Enter to start, type the paragraph, press Enter to finish.
3. Run with precomputed timestamps and typed text (example):
   ```bash
   # startMillis endMillis typedWords...
   java Main 1629900000000 1629900060000 "Data Strucrures and Algorthms are powerfull."
   ```

## How to connect frontend -> backend (optional)
The project intentionally keeps the Java backend as a standalone library. To make the frontend call the Java logic you'll need a small bridge (examples):
- Create a minimal REST wrapper (e.g. using Spring Boot or Micronaut) that calls `TypingTest` from HTTP endpoints.
- Or produce a Node.js child-process bridge that invokes `java Main <args>` and returns results.

If you want, I can provide a small Spring Boot starter that exposes an endpoint `/evaluate` which accepts `{ typed, start, end }` and returns the `TestResult` JSON. (No servlets; Spring Boot is a lightweight option.)

## Files included
- backend/StringMatcher.java
- backend/TypingTest.java
- backend/TestResult.java
- backend/Main.java
- frontend/index.html
- frontend/style.css
- frontend/script.js
- README.md

----
Enjoy! If you want the Java backend exposed as a REST API (so the frontend can call it directly) I can add a minimal Spring Boot project in the same repo.
